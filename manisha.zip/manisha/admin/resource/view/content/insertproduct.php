<?php

echo "hello";
if(isset($_POST['create_product']))
{
	#== NEW IMAGE FILE NAME GENERATE
	$filemasname = "PRODUCT_" . date("YmdHis") . "_" . $_FILES['product_master_image']['name'];
	$fileaddonename = "PRODUCTONE_" . date("YmdHis") . "_" . $_FILES['product_master_image']['name'];
	$fileaddtwoname = "PRODUCTTWO_" . date("YmdHis") . "_" . $_FILES['product_master_image']['name'];
	$fileaddthreename = "PRODUCTTHREE_" . date("YmdHis") . "_" . $_FILES['product_master_image']['name'];
	
	#== IMAGE FILE VALIDATION
	$prodmstrResult = $control->checkImage($_FILES['product_master_image']['type'], $_FILES['product_master_image']['size'], $_FILES['product_master_image']['error']);
	$prodaddoneResult = $control->checkImage($_FILES['products_image_one']['type'], $_FILES['products_image_one']['size'], $_FILES['products_image_one']['error']);
	$prodaddtwoResult = $control->checkImage($_FILES['products_image_two']['type'], $_FILES['products_image_two']['size'], $_FILES['products_image_two']['error']);
	$prodaddthreeResult = $control->checkImage($_FILES['products_image_three']['type'], $_FILES['products_image_three']['size'], $_FILES['products_image_three']['error']);
	
	// && $prodaddoneResult == 1 && $prodaddtwoResult == 1 && $prodaddthreeResult == 1
	
	if($prodmstrResult == 1)
	{
		$tableName = $columnValue = null;
		$tableName = "products";
		$columnValue["category_id"] = $_POST['category_id'];
		$columnValue["subcategory_id"] = $_POST['subcategory_id'];
		$columnValue["product_name"] = $_POST['product_name'];
		$columnValue["product_summary"] = $_POST['product_summary'];
		$columnValue["product_details"] = $_POST['product_details'];
		$columnValue["product_quantity"] = $_POST['product_quantity'];
		$columnValue["product_price"] = $_POST['product_price'];
		$columnValue["product_status"] = $_POST['product_status'];
		$columnValue["product_featured"] = $_POST['product_featured'];
		$columnValue["product_master_image"] = $filemasname;
		$columnValue["products_image_one"] = $fileaddonename;
		$columnValue["products_image_two"] = $fileaddtwoname;
		$columnValue["products_image_three"] = $fileaddthreename;
		$columnValue["product_tags"] = $_POST['product_tag'];
		$columnValue["created_at"] = date("Y-m-d H:i:s");
		$createProduct = $eloquent->insertData($tableName, $columnValue);
		
		if($createProduct > 0)
		{
			#== ADD IMAGE TO THE DIRECTORY
			move_uploaded_file($_FILES['product_master_image']['tmp_name'], $GLOBALS['PRODUCT_DIRECTORY'] . $filemasname);
			move_uploaded_file($_FILES['products_image_one']['tmp_name'], $GLOBALS['PRODUCTADD_DIRECTORY'] . $fileaddonename);
			move_uploaded_file($_FILES['products_image_two']['tmp_name'], $GLOBALS['PRODUCTADD_DIRECTORY'] . $fileaddtwoname);
			move_uploaded_file($_FILES['products_image_three']['tmp_name'], $GLOBALS['PRODUCTADD_DIRECTORY'] . $fileaddthreename);
		}
	}
}

?>