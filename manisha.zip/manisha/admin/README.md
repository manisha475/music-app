## Admin Control Panel


### BackEnd Application Folder Structure

```
├───app
│   ├───Http
│   │   └───Controllers
│   └───Models
├───config
├───images
├───public
│   ├───css
│   ├───fonts
│   ├───js
│   ├───summernote
│   └───tagplug
└───resource
    ├───backup
    ├───schema
    └───view
        ├───content
        └───include
```
